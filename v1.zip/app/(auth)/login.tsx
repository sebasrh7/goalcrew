import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '../../src/store/authStore';
import { Button } from '../../src/components/UI';
import { Colors, Spacing, FontSize } from '../../src/constants';

export default function LoginScreen() {
  const router = useRouter();
  const { signInWithGoogle, isLoading } = useAuthStore();

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
      router.replace('/(tabs)');
    } catch (error: any) {
      Alert.alert('Error', error.message ?? 'No se pudo iniciar sesión con Google.');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#1a1555', '#0b0f1a']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Atrás</Text>
        </TouchableOpacity>

        <Text style={styles.title}>Bienvenido de vuelta ✈️</Text>
        <Text style={styles.subtitle}>Inicia sesión para continuar tu aventura</Text>

        <View style={styles.buttonContainer}>
          <Button
            title="Continuar con Google"
            onPress={handleGoogleLogin}
            isLoading={isLoading}
            icon="🔐"
            style={{ marginTop: Spacing.xl }}
          />
        </View>

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>o</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity onPress={() => router.push('/(auth)/register')} style={styles.registerLink}>
          <Text style={styles.registerText}>
            ¿No tienes cuenta? <Text style={styles.registerHighlight}>Regístrate gratis</Text>
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  scroll: { padding: Spacing.xl, paddingTop: Spacing.lg, flexGrow: 1 },
  backBtn: { marginBottom: Spacing.xxl },
  backText: { color: Colors.accent2, fontWeight: '700', fontSize: FontSize.base },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: '900',
    color: Colors.text,
    marginBottom: Spacing.sm,
    letterSpacing: -0.5,
  },
  subtitle: { fontSize: FontSize.base, color: Colors.text2, marginBottom: Spacing.xxl },
  buttonContainer: { gap: Spacing.lg },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginVertical: Spacing.xl,
  },
  dividerLine: { flex: 1, height: 1, backgroundColor: Colors.surface3 },
  dividerText: { color: Colors.text3, fontSize: FontSize.sm },
  registerLink: { alignItems: 'center' },
  registerText: { fontSize: FontSize.base, color: Colors.text2 },
  registerHighlight: { color: Colors.accent2, fontWeight: '700' },
});
