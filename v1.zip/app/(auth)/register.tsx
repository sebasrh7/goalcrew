import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '../../src/store/authStore';
import { Button } from '../../src/components/UI';
import { Colors, Spacing, FontSize } from '../../src/constants';

export default function RegisterScreen() {
  const router = useRouter();
  const { signInWithGoogle, isLoading } = useAuthStore();

  const handleGoogleRegister = async () => {
    try {
      await signInWithGoogle();
      router.replace('/(tabs)');
    } catch (error: any) {
      Alert.alert('Error', error.message ?? 'No se pudo registrar con Google.');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#1a1555', '#0b0f1a']} style={StyleSheet.absoluteFill} />
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Atrás</Text>
        </TouchableOpacity>

        <Text style={styles.title}>Crea tu cuenta 🚀</Text>
        <Text style={styles.subtitle}>Únete a miles de crews viajando juntos</Text>

        <View style={styles.buttonContainer}>
          <Button
            title="Registrarse con Google"
            onPress={handleGoogleRegister}
            isLoading={isLoading}
            icon="🚀"
            style={{ marginTop: Spacing.xl }}
          />
        </View>

        <Text style={styles.terms}>
          Al registrarte aceptas nuestros{' '}
          <Text style={styles.termsLink}>Términos de Servicio</Text>
          {' '}y{' '}
          <Text style={styles.termsLink}>Política de Privacidad</Text>
        </Text>

        <TouchableOpacity onPress={() => router.push('/(auth)/login')} style={styles.loginLink}>
          <Text style={styles.loginText}>
            ¿Ya tienes cuenta? <Text style={styles.loginHighlight}>Inicia sesión</Text>
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  scroll: { padding: Spacing.xl, paddingTop: Spacing.lg, flexGrow: 1 },
  backBtn: { marginBottom: Spacing.xxl },
  backText: { color: Colors.accent2, fontWeight: '700', fontSize: FontSize.base },
  title: {
    fontSize: FontSize.xxxl,
    fontWeight: '900',
    color: Colors.text,
    marginBottom: Spacing.sm,
    letterSpacing: -0.5,
  },
  subtitle: { fontSize: FontSize.base, color: Colors.text2, marginBottom: Spacing.xxl },
  buttonContainer: { gap: Spacing.lg },
  terms: {
    fontSize: FontSize.sm,
    color: Colors.text2,
    textAlign: 'center',
    marginVertical: Spacing.xl,
  },
  termsLink: { color: Colors.accent2, fontWeight: '600' },
  loginLink: { alignItems: 'center', marginTop: Spacing.xl },
  loginText: { fontSize: FontSize.base, color: Colors.text2 },
  loginHighlight: { color: Colors.accent2, fontWeight: '700' },
});
