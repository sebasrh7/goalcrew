import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as Linking from 'expo-linking';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useAuthStore, initAuthListener } from '../src/store/authStore';
import { supabase } from '../src/lib/supabase';
import { triggerOAuthCallback, setOAuthSessionCallback } from '../src/lib/oauthCallback';

// Keep the splash screen visible while we fetch resources
SplashScreen.preventAutoHideAsync();

const prefix = Linking.createURL('/');

export default function RootLayout() {
  const { isLoading } = useAuthStore();

  useEffect(() => {
    // Initialize Supabase auth listener
    initAuthListener();

    // Registra el callback de OAuth (para que supabase.ts pueda llamarlo)
    setOAuthSessionCallback(() => {
      // Placeholder - se reemplaza en supabase.ts
    });

    // ✅ Intenta obtener la URL inicial (en caso de que la app se abrió desde el deep link)
    const getInitialURL = async () => {
      const url = await Linking.getInitialURL();
      if (url != null) {
        console.log('🔗 INITIAL URL:', url);
        // Procesa como si fuera un deep link normal
        handleDeepLink(url);
      }
    };

    getInitialURL();

    // Handle OAuth callback from deep linking
    const subscription = Linking.addEventListener('url', (event) => {
      console.log('🔗 Deep link event received:', event.url);
      handleDeepLink(event.url);
    });

    const handleDeepLink = async (url: string) => {
      console.log('🔗 Processing deep link:', url);
      
      try {
        // Espera a que Supabase procese la URL con la sesión
        console.log('⏳ Waiting 2 seconds for Supabase to process...');
        await new Promise(r => setTimeout(r, 2000));
        
        const { data: sessionData, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ Error getting session:', error);
        } else if (sessionData?.session) {
          console.log('✅✅ Session confirmed in layout:', sessionData.session.user?.email);
          // Notifica al componente de login que la sesión está lista
          triggerOAuthCallback(sessionData.session);
        } else {
          console.warn('⚠️  No session after deep link received');
          // Intenta una vez más después de esperar
          await new Promise(r => setTimeout(r, 1000));
          const { data: retrySession, error: retryError } = await supabase.auth.getSession();
          if (retrySession?.session) {
            console.log('✅✅ Session confirmed (retry):', retrySession.session.user?.email);
            triggerOAuthCallback(retrySession.session);
          } else {
            console.error('❌ Still no session after retry');
          }
        }
      } catch (error) {
        console.error('❌ Error handling deep link:', error);
      }
    };

    return () => subscription.remove();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      SplashScreen.hideAsync();
    }
  }, [isLoading]);

  if (isLoading) return null;

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(auth)" options={{ animation: 'fade' }} />
          <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
          <Stack.Screen name="group/[id]" options={{ animation: 'slide_from_right' }} />
        </Stack>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
