import { create } from 'zustand';
import { signInWithGoogle } from '../lib/supabase';
import { supabase } from '../lib/supabase';
import { User, AuthState } from '../types';

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  session: null,
  isLoading: true,
  isAuthenticated: false,

  signInWithGoogle: async () => {
    set({ isLoading: true });
    try {
      await signInWithGoogle();
      console.log('✅ signInWithGoogle completed');
      // La sesión se establecerá automáticamente via onAuthStateChange
      // Espera un poco para que se procese
      await new Promise(r => setTimeout(r, 500));
    } catch (error) {
      console.error('❌ signInWithGoogle error:', error);
      set({ isLoading: false });
      throw error;
    }
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ user: null, session: null, isAuthenticated: false });
  },

  updateProfile: async (data: Partial<User>) => {
    const { user } = get();
    if (!user) return;

    const { data: updated, error } = await supabase
      .from('users')
      .update(data)
      .eq('id', user.id)
      .select()
      .single();
    if (error) throw error;
    set({ user: updated });
  },
}));

// ─── Initialize auth listener ─────────────────────────────────────────────────
export function initAuthListener() {
  console.log('🔔 Initializing auth listener...');
  
  // Check current session
  supabase.auth.getSession().then(async ({ data: { session }, error }) => {
    if (error) {
      console.error('❌ Error getting session:', error);
      useAuthStore.setState({ isLoading: false });
      return;
    }
    
    if (session?.user) {
      console.log('✅ Session found:', session.user.email);
      try {
        const profile = await fetchProfile(session.user.id);
        useAuthStore.setState({ user: profile, session, isAuthenticated: true, isLoading: false });
      } catch (err) {
        console.warn('⚠️  Could not fetch profile, using user data:', err);
        useAuthStore.setState({ user: session.user as any, session, isAuthenticated: true, isLoading: false });
      }
    } else {
      console.log('No existing session');
      useAuthStore.setState({ isLoading: false });
    }
  });

  // Listen for auth state changes
  supabase.auth.onAuthStateChange(async (event, session) => {
    console.log(`🔔 Auth state changed: ${event}`, session?.user?.email ?? '');
    
    if (event === 'SIGNED_IN' && session?.user) {
      console.log('✅ User signed in:', session.user.email);
      try {
        const profile = await fetchProfile(session.user.id);
        useAuthStore.setState({ user: profile, session, isAuthenticated: true, isLoading: false });
      } catch (err) {
        console.warn('⚠️  Could not fetch profile:', err);
        useAuthStore.setState({ user: session.user as any, session, isAuthenticated: true, isLoading: false });
      }
    } else if (event === 'SIGNED_OUT') {
      console.log('👋 User signed out');
      useAuthStore.setState({ user: null, session: null, isAuthenticated: false, isLoading: false });
    } else if (event === 'TOKEN_REFRESHED') {
      console.log('🔄 Token refreshed');
    }
  });
}

async function fetchProfile(userId: string): Promise<User> {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    if (error) {
      console.warn('❌ Profile fetch error:', error.message);
      throw error;
    }
    console.log('✅ Profile loaded:', data.email);
    return data;
  } catch (error) {
    console.error('❌ fetchProfile failed:', error);
    throw error;
  }
}
